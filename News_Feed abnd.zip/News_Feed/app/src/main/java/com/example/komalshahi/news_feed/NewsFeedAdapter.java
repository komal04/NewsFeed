package com.example.komalshahi.news_feed;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class NewsFeedAdapter extends ArrayAdapter<NewsFeed> {

    String title;
    String name;
    private static final String LOCATION_SEPARATOR = " of ";


    public NewsFeedAdapter(Context context, List<NewsFeed> News) {
        super(context, 0, News);

    }

    private String formatDate(Date dateObject) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("LLL dd, yyyy");
        return dateFormat.format(dateObject);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.newsfeed_listitem, parent, false);
        }
        NewsFeed currentNewsFeed = getItem(position);

        String title = currentNewsFeed.getmTitle();
        TextView locationOffsetView = (TextView) listItemView.findViewById(R.id.title);
        locationOffsetView.setText(title);

        String author = currentNewsFeed.getmAuthor();
        TextView authorname = (TextView) listItemView.findViewById(R.id.author);
        authorname.setText(author);

        String type = currentNewsFeed.getmType();
        TextView Type = (TextView) listItemView.findViewById(R.id.type);
        Type.setText(type);

        Date dateObject = new Date(String.valueOf(currentNewsFeed.getTime()));
        TextView dateView = (TextView) listItemView.findViewById(R.id.date);
        String formattedDate = formatDate(dateObject);
        dateView.setText(formattedDate);
        return listItemView;
    }
}
