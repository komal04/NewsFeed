package com.example.komalshahi.news_feed;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Date;

public class NewsFeed  {
 private String Title ;
 public Date TimeInMilliseconds;
 private String Url;
 private String Type;
 private String Author;

public NewsFeed (String title ,  Date timeInMilliseconds , String url, String type, String author){
    Title = title;
    TimeInMilliseconds = timeInMilliseconds;
    Url = url;
    Type = type;
    Author = author;
}

public String getmTitle(){ return Title;}
public Date getTime() { return TimeInMilliseconds;}
public String getmUrl(){ return Url;}
public String getmType(){return Type;}

    public String getmAuthor() {
        return Author;
    }
}
